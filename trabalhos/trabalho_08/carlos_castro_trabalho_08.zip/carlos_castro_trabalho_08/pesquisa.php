<?php
require_once 'components/header.php';
require_once 'views/pesquisa_view.php';
require_once 'components/footer.php';
?>

