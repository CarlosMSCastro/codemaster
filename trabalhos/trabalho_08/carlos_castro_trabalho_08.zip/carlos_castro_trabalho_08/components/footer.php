
  <footer class="text-center text-white py-3 fs-6 mt-5 bg-danger">
    Carlos Castro &copy; 2025
  </footer>

</body>
</html>